var ip = "https://booktobook.herokuapp.com/";
//var ip = "http://localhost:8080/";


$( '#shopping-link' ).click(function(e) {
    e.preventDefault();
    if(true){
        displayWarning();
    }else{
        location.href = "../pages/shoppingCart.html";
    }
});


//<button type="button" class="close" data-dismiss="alert">&times;</button>
var displayWarning = function(){
    //document.getElementById("#warning-row").innerHTML = "";
    $("#warning-col").html("");
    var $alert = $("<div class='alert alert-warning alert-dismissible show' />");
    //var $col1 = $("<div class='col-11 no-top-pad' />");
    var $message = $("<span />");
    $message.html("To access the shopping cart perform login/registration");
    //var $col2 = $("<div class='col-1 no-top-pad' />");
    var $button = $("<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>");
    $("#warning-col").append($alert);
    //$alert.append($col1);
    //$alert.append($col2);
    $alert.append($message);
    $alert.append($button);
};


