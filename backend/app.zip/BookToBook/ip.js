//export var ip = "https://booktobook.herokuapp.com"
export const ip = "http://localhost:8080"
